// demo_origin_game_logic.
#include "demo_origin_game.h"

using namespace std;
using namespace PSAG_LOGGER;

void DemoGameOrigin::GameActorPawnTrans(float time_step) {
	auto PawnActor   = DemoActors->FindGameActor(PawnActorCode);
	auto PawnFxActor = DemoActors->FindGameActor(PawnActorFxCode);

	// ================================ "Actor"�����ƶ� ================================
	// move: x: +vec, y: -vec.
	if (ImGui::IsKeyDown(ImGuiKey_W)) PawnActorMove.vector_x += -0.02f * time_step;
	if (ImGui::IsKeyDown(ImGuiKey_S)) PawnActorMove.vector_x +=  0.02f * time_step;

	// rotate: x: +vec, y: -vec.
	if (ImGui::IsKeyDown(ImGuiKey_A)) PawnActorRotate.vector_x +=  10.0f * time_step;
	if (ImGui::IsKeyDown(ImGuiKey_D)) PawnActorRotate.vector_x += -10.0f * time_step;

	PawnActorMove.vector_x   += (0.0f - PawnActorMove.vector_x)   * 0.01f * time_step;
	PawnActorRotate.vector_x += (0.0f - PawnActorRotate.vector_x) * 0.01f * time_step;

	PawnActorMove.vector_x   = PSAG_IMVEC_CLAMP(PawnActorMove.vector_x,   -PawnActorMove.vector_y,   PawnActorMove.vector_y);
	PawnActorRotate.vector_x = PSAG_IMVEC_CLAMP(PawnActorRotate.vector_x, -PawnActorRotate.vector_y, PawnActorRotate.vector_y);

	PawnActor->ActorApplyForceRotate(PawnActorRotate.vector_x);
	// angle => calc => move vector.
	PawnActor->ActorApplyForceMove(Vector2T<float>(
		PawnActorMove.vector_x * cos(PSAG_M_DEGRAD(PawnActor->ActorGetRotate())),
		PawnActorMove.vector_x * sin(PSAG_M_DEGRAD(PawnActor->ActorGetRotate()))
	));

	// ================================ FxActor ���� PawnActor ================================
	PawnFxActor->ActorModifyState(PawnActor->ActorGetPosition(), PawnActor->ActorGetRotate());

	// ================================ �����ȡ"Actor"���� ================================
	
}

void DemoGameOrigin::GamePostProcessing(GameLogic::FrameworkParams& params) {
	// ================================ ��Ϸ���ڴ������� ================================
	params.ShaderParamsFinal->GameSceneBloomRadius = 12;
	params.ShaderParamsFinal->GameSceneFilterAVG   = 1.0f;

	params.ShaderParamsFinal->GameSceneOutContrast = 1.115f;
	params.ShaderParamsFinal->GameSceneOutColor    = Vector3T<float>(1.28f, 1.12f, 1.0f);
}

bool DemoGameOrigin::LogicInitialization(const Vector2T<uint32_t>& WinSize) {
	// ================================ ���� ȫ������ϵͳ ================================
	// mode(1): create, (2): delete.
	PsagActor::OperPhysicalWorld CreatePhysics("DemoOrigin", 1);

	// ================================ ���� ����������� ================================
    DemoShaders = new PsagActor::ShaderManager();
	DemoStatic  = new PsagActor::BricksManager();
	DemoActors  = new PsagActor::ActorsManager();

	GameCreateShaderResource(DemoShaders, WinSize);
	GameCreateStaticScene();

	// ����Actors���Ͱ�.
	PsagActorType::ActorTypeAllotter.ActorTypeCreate("ActorPawn");
	PsagActorType::ActorTypeAllotter.ActorTypeCreate("ActorBullet");
	PsagActorType::ActorTypeAllotter.ActorTypeCreate("ActorNPC");

	GameCreatePawnActor(&PawnActorCode, &PawnActorFxCode);

	PawnActorShader   = DemoShaders->FindActorShader("actor_pawn");
	PawnActorFxShader = DemoShaders->FindActorShader("actor_base_fx");

	PawnActorMove.vector_y   = 3.8f;
	PawnActorRotate.vector_y = 3.2f;
	
	PlayerCamera = new PsagManager::Tools::Camera::GamePlayerCameraGM(
		Vector2T<float>(-500.0f, -500.0f), Vector2T<float>(500.0f, 500.0f)
	);

	CameraScaleLerp.x = 0.5f;
	return true;
}

void DemoGameOrigin::LogicCloseFree() {
	// ================================ ���� ����������� ================================
	delete DemoShaders;
	delete DemoStatic;
	delete DemoActors;

	delete PlayerCamera;

	PsagActor::OperPhysicalWorld DeletePhysics("DemoOrigin", 2);
}

bool DemoGameOrigin::LogicEventLoopGame(GameLogic::FrameworkParams& RunningState) {
	GamePostProcessing(RunningState);

	DemoStatic->RunAllGameBrick();
	DemoActors->RunAllGameActor();

	// ================================ "Actor"��ɫ������ ================================
	PawnActorFxLightBarPosition[0] -= RunningState.GameRunTimeSTEP * 0.002f;
	PawnActorFxLightBarPosition[0] = PawnActorFxLightBarPosition[0] < -0.5f ? 1.5f : PawnActorFxLightBarPosition[0];
	PawnActorFxLightBarPosition[1] -= RunningState.GameRunTimeSTEP * 0.008f;
	PawnActorFxLightBarPosition[1] = PawnActorFxLightBarPosition[1] < -0.35f ? 1.35f : PawnActorFxLightBarPosition[1];

	auto PawnUniform = [&]() {
		PawnActorShader->UniformFP32("BarWidth", 1.0f);
		PawnActorShader->UniformFP32("BarPosition", PawnActorFxLightBarPosition[0]);
		PawnActorShader->UniformFP32("Figure", PawnActorFigure);
	};
	PawnActorShader->UniformSetContext(PawnUniform);

	auto PawnFxUniform = [&]() {
		PawnActorFxShader->UniformFP32("BarWidth", 0.7f);
		PawnActorFxShader->UniformFP32("BarPosition", PawnActorFxLightBarPosition[1]);
	};
	PawnActorFxShader->UniformSetContext(PawnFxUniform);

	// ================================ ����"Actor" & ����Gui ================================

	GameActorPawnTrans(RunningState.GameRunTimeSTEP);
	GameRenderGui();
	
	// camera scale_lerp calc, const speed value 0.15
	CameraScaleLerp.y += (CameraScaleLerp.x - CameraScaleLerp.y) * 0.1f * RunningState.GameRunTimeSTEP;
	// setting scale_lerp value.
	CameraScaleLerp.x += ImGui::GetIO().MouseWheel * 0.1f;
	CameraScaleLerp.x = PSAG_IMVEC_CLAMP(CameraScaleLerp.x, 0.2f, 1.32f);

	if (ImGui::IsMouseDown(ImGuiMouseButton_Left))
		PlayerCamera->PlayerCameraRun(Vector2T<float>(ImGui::GetIO().MouseDelta.x, ImGui::GetIO().MouseDelta.y), CameraScaleLerp.y);

	RunningState.CameraParams->MatrixPosition = PlayerCamera->GetCameraPosition();
	RunningState.CameraParams->MatrixScale    = Vector2T<float>(CameraScaleLerp.y, CameraScaleLerp.y);
	return true;
}